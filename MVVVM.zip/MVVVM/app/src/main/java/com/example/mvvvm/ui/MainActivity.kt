package com.example.mvvvm.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.mvvvm.R
import com.example.mvvvm.databinding.MainActDataBinding

class MainActivity : AppCompatActivity() {

    var binding: MainActDataBinding? = null
    var counterDataBinding = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding?.lifecycleOwner = this


        buttonClicks()

        binding?.root
    }

    private fun buttonClicks() {
        binding?.button?.setOnClickListener {
            counterDataBinding = counterDataBinding++

        }
    }
}