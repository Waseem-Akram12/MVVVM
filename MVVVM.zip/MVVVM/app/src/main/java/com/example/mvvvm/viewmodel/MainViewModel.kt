package com.example.mvvvm.viewmodel

import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel() {

}